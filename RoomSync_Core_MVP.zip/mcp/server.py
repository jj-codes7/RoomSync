from mcp.server.fastmcp import FastMCP

mcp = FastMCP("RoomSync")

@mcp.tool()
def calculate_weekly_conflict(quiet_start: str, call_start: str, call_end: str, number_of_days: int) -> dict:
    """Calculate late-evening call overlap with a roommate's quiet-hours start."""
    def minutes(t):
        h, m = map(int, t.split(":"))
        return h * 60 + m
    overlap = max(0, minutes(call_end) - max(minutes(call_start), minutes(quiet_start)))
    total = overlap * number_of_days
    return {"minutes_per_day": overlap, "weekly_minutes": total, "weekly_hours": total / 60}

@mcp.tool()
def suggest_adjustment() -> str:
    """Suggest a neutral next step for roommates to discuss."""
    return "Could late calls happen in a common room, if both roommates agree?"

if __name__ == "__main__":
    mcp.run()
